<?php
//  localhost Database connection
    $conn=mysqli_connect('localhost','root','','mywebsite') or die('connection not sucessful'.mysqli_connect_errors());

//  mysql.freehostia.com Database connection
//  $conn=mysqli_connect('mysql.freehostia.com','soumon8_mywebsite','@Soumo2001@','soumon8_mywebsite') or die('connection not sucessful'.mysqli_connect_errors());   
    

    
?>