<?php
    $conn=mysqli_connect('localhost','root','','mywebsite') or die('connection not sucessful'.mysqli_connect_errors());
?>