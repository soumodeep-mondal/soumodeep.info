<?php
    $conn=mysqli_connect('sql306.epizy.com','epiz_33356292','3wyga9vzySGMqwa','epiz_33356292_phpmysqldb') or die('connection not sucessful'.mysqli_connect_errors());


    echo "sucess";
?>